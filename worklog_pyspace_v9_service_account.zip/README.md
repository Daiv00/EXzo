# WorkLog v9 — автоматическая синхронизация Google Drive

Версия для PySpace/Render. Google OAuth не используется. Google Drive подключается через Service Account.

## Важно для PySpace

Если среда не установила зависимости автоматически, в терминале проекта выполните:

```bash
pip install -r requirements.txt
```

В этой версии **нет зависимостей `google-auth` и `google-api-python-client`**: Drive API вызывается напрямую по HTTPS. Это устраняет ошибки `No module named google`.

## Google Drive

1. Создайте Service Account в Google Cloud.
2. Создайте JSON key.
3. Расшарьте папку Drive на `client_email` Service Account с правом Editor.
4. В WorkLog → Настройки → Google Drive загрузите JSON.
5. Нажмите «Проверить и создать папку».

Приватный JSON-ключ не добавляйте в GitHub.
