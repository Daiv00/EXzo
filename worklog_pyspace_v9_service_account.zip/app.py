from flask import Flask, jsonify, render_template, request, redirect, session, url_for, send_file, make_response
from werkzeug.security import generate_password_hash as werkzeug_generate, check_password_hash as werkzeug_check
from werkzeug.middleware.proxy_fix import ProxyFix
from pathlib import Path
from datetime import datetime, date
import sqlite3, os, io, json, secrets, hashlib, re, time, base64, requests
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "worklog.db"

app = Flask(__name__, template_folder=str(BASE_DIR/"templates"), static_folder=str(BASE_DIR/"static"))
# PySpace/Render sits behind an HTTPS reverse proxy. Trust the single proxy hop so
# Flask sees the original scheme/host and can issue correct secure cookies.
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_urlsafe(48)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1") == "1",
    MAX_CONTENT_LENGTH=256 * 1024,
)

# Small in-process rate limiter for authentication endpoints. It is intentionally
# conservative; a reverse proxy/WAF should still be used in production.
_login_attempts = {}

def _rate_limited(ip, bucket="login", limit=8, window=300):
    now=time.time(); key=(bucket, ip)
    arr=[t for t in _login_attempts.get(key, []) if now-t < window]
    if len(arr) >= limit:
        _login_attempts[key]=arr
        return True
    arr.append(now); _login_attempts[key]=arr
    return False

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          is_admin INTEGER NOT NULL DEFAULT 0,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS shifts(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          work_date TEXT NOT NULL,
          start_time TEXT NOT NULL,
          end_time TEXT,
          role TEXT NOT NULL DEFAULT 'Официант',
          tips REAL NOT NULL DEFAULT 0,
          note TEXT DEFAULT '',
          status TEXT NOT NULL DEFAULT 'completed',
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_shifts_user_date ON shifts(user_id, work_date);
        CREATE TABLE IF NOT EXISTS google_tokens(
          user_id INTEGER PRIMARY KEY,
          token_json TEXT NOT NULL,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS drive_backups(
          user_id INTEGER PRIMARY KEY,
          file_id TEXT NOT NULL,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS drive_config(
          id INTEGER PRIMARY KEY CHECK (id=1),
          admin_user_id INTEGER NOT NULL,
          folder_id TEXT NOT NULL,
          folder_url TEXT,
          folder_name TEXT NOT NULL DEFAULT 'WorkLog — Смены',
          public_read INTEGER NOT NULL DEFAULT 1,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS app_settings(
          id INTEGER PRIMARY KEY CHECK (id=1),
          google_client_id TEXT,
          google_client_secret_enc TEXT,
          google_redirect_uri TEXT,
          folder_name TEXT NOT NULL DEFAULT 'WorkLog — Смены',
          public_read INTEGER NOT NULL DEFAULT 1,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """)
        # Lightweight migrations for databases created by older ZIP versions.
        cols={r[1] for r in con.execute("PRAGMA table_info(users)").fetchall()}
        if "is_admin" not in cols: con.execute("ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0")
        acols={r[1] for r in con.execute("PRAGMA table_info(app_settings)").fetchall()}
        if "folder_name" not in acols: con.execute("ALTER TABLE app_settings ADD COLUMN folder_name TEXT NOT NULL DEFAULT 'WorkLog — Смены'")
        if "public_read" not in acols: con.execute("ALTER TABLE app_settings ADD COLUMN public_read INTEGER NOT NULL DEFAULT 1")
        if "service_account_enc" not in acols: con.execute("ALTER TABLE app_settings ADD COLUMN service_account_enc TEXT")
        if "drive_admin_email" not in acols: con.execute("ALTER TABLE app_settings ADD COLUMN drive_admin_email TEXT")
        dcols={r[1] for r in con.execute("PRAGMA table_info(drive_config)").fetchall()}
        if "folder_name" not in dcols: con.execute("ALTER TABLE drive_config ADD COLUMN folder_name TEXT NOT NULL DEFAULT 'WorkLog — Смены'")
        if "public_read" not in dcols: con.execute("ALTER TABLE drive_config ADD COLUMN public_read INTEGER NOT NULL DEFAULT 1")
        # Bootstrap the admin role once from the legacy environment setting.
        admin_name=os.environ.get("ADMIN_USERNAME", "admin").strip()
        if admin_name:
            con.execute("UPDATE users SET is_admin=1 WHERE username=?", (admin_name,))
        if con.execute("SELECT COUNT(*) FROM users WHERE is_admin=1").fetchone()[0] == 0:
            first=con.execute("SELECT id FROM users ORDER BY id LIMIT 1").fetchone()
            if first: con.execute("UPDATE users SET is_admin=1 WHERE id=?", (first[0],))


def current_user():
    uid = session.get("user_id")
    if not uid: return None
    with db() as con:
        return con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()

def is_admin(u): return bool(u and int(u["is_admin"] or 0)==1)

def login_required_page(): return redirect(url_for("auth_page"))

CSRF_COOKIE = "worklog_csrf"

def csrf_token():
    # Keep CSRF independent from the Flask session. This is important for
    # reverse-proxied Web Preview environments where a session may be rotated
    # during login or between preview requests.
    token = request.cookies.get(CSRF_COOKIE)
    if not token or len(token) < 32:
        token = secrets.token_urlsafe(32)
    return token

@app.before_request
def security_gate():
    if request.method not in {"POST","PUT","PATCH","DELETE"} or request.path in {"/api/login","/api/register"}:
        return None

    # PySpace Web Preview can be embedded/proxied in a way that prevents
    # the CSRF cookie from being sent. Prefer a strict same-origin check
    # when the browser supplies Origin/Referer, and use the CSRF token when
    # available. This keeps protection effective without breaking preview.
    origin = request.headers.get("Origin")
    if origin:
        from urllib.parse import urlparse
        try:
            o = urlparse(origin)
            if o.scheme != request.scheme or o.netloc != request.host:
                return jsonify(error="Проверка безопасности не пройдена."), 403
        except Exception:
            return jsonify(error="Проверка безопасности не пройдена."), 403

    referer = request.headers.get("Referer")
    if referer and not origin:
        from urllib.parse import urlparse
        try:
            r = urlparse(referer)
            if r.scheme != request.scheme or r.netloc != request.host:
                return jsonify(error="Проверка безопасности не пройдена."), 403
        except Exception:
            return jsonify(error="Проверка безопасности не пройдена."), 403

    supplied = request.headers.get("X-CSRF-Token", "")
    expected = request.cookies.get(CSRF_COOKIE, "")
    if expected and supplied:
        if len(supplied) > 200 or not secrets.compare_digest(supplied, expected):
            return jsonify(error="Проверка безопасности не пройдена. Обнови страницу и попробуй снова."), 403
    # If the proxy/browser strips the CSRF cookie/header, same-origin Origin
    # or Referer validation above remains the fallback protection.

@app.after_request
def security_headers(resp):
    resp.headers["X-Content-Type-Options"]="nosniff"
    resp.headers["X-Frame-Options"]="DENY"
    resp.headers["Referrer-Policy"]="same-origin"
    resp.headers["Permissions-Policy"]="camera=(), microphone=(), geolocation=()"
    resp.headers["Content-Security-Policy"]="default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    if request.is_secure:
        resp.headers["Strict-Transport-Security"]="max-age=31536000; includeSubDomains"
    return resp

def hours_between(start, end):
    if not start or not end: return 0
    try:
        a=datetime.strptime(start,"%H:%M"); b=datetime.strptime(end,"%H:%M")
        mins=(b-a).total_seconds()/60
        if mins < 0: mins += 1440
        return round(mins/60,2)
    except ValueError: return 0

def serialize(r):
    x=dict(r); x["hours"]=hours_between(x["start_time"],x["end_time"]); return x

def valid_text(v, max_len=300):
    s=str(v or "").strip()
    return s if len(s)<=max_len else None

# ---- password / encryption helpers ----
def password_hash(password):
    try:
        from argon2 import PasswordHasher
        return "argon2$" + PasswordHasher(time_cost=2,memory_cost=19456,parallelism=1).hash(password)
    except ImportError:
        return werkzeug_generate(password, method="scrypt")

def password_check(stored,password):
    if stored.startswith("argon2$"):
        try:
            from argon2 import PasswordHasher
            return PasswordHasher(time_cost=2,memory_cost=19456,parallelism=1).verify(stored[7:], password)
        except Exception: return False
    try: return werkzeug_check(stored,password)
    except Exception: return False

def password_needs_upgrade(stored): return not stored.startswith("argon2$")

def crypto():
    from cryptography.fernet import Fernet
    digest=hashlib.sha256(app.secret_key.encode()).digest()
    return Fernet(__import__('base64').urlsafe_b64encode(digest))

def encrypt_secret(value): return crypto().encrypt(value.encode()).decode() if value else ""
def decrypt_secret(value):
    if not value: return ""
    try: return crypto().decrypt(value.encode()).decode()
    except Exception: return ""

# ---- pages / auth ----
@app.get("/")
def index():
    if not current_user(): return login_required_page()
    return render_template("index.html", user=current_user()["username"], is_admin=is_admin(current_user()))

@app.get("/login")
def auth_page():
    if current_user(): return redirect(url_for("index"))
    return render_template("auth.html")

@app.get("/api/csrf")
def api_csrf():
    token = csrf_token()
    resp = make_response(jsonify(token=token))
    resp.set_cookie(CSRF_COOKIE, token, httponly=False, secure=app.config.get("SESSION_COOKIE_SECURE", True), samesite="Lax", path="/")
    return resp

@app.post("/api/register")
def register():
    ip=request.remote_addr or "unknown"
    if _rate_limited(ip,"auth",8,300): return jsonify(error="Слишком много попыток. Попробуй позже."),429
    data=request.get_json(silent=True) or {}; username=valid_text(data.get("username"),40); password=str(data.get("password", ""))
    if not username or len(username)<3 or len(password)<8: return jsonify(error="Логин минимум 3 символа, пароль минимум 8"),400
    if not re.fullmatch(r"[A-Za-zА-Яа-яЁё0-9_.-]+",username): return jsonify(error="В логине разрешены буквы, цифры, _, . и -"),400
    try:
        with db() as con:
            count=con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            cur=con.execute("INSERT INTO users(username,password_hash,is_admin) VALUES(?,?,?)",(username,password_hash(password),1 if count==0 else 0)); uid=cur.lastrowid
        session.clear(); session["user_id"]=uid; csrf_token(); auto_backup(uid)
        return jsonify(ok=True)
    except sqlite3.IntegrityError: return jsonify(error="Такой логин уже занят"),409

@app.post("/api/login")
def login():
    ip=request.remote_addr or "unknown"
    if _rate_limited(ip,"auth",8,300): return jsonify(error="Слишком много попыток. Попробуй позже."),429
    data=request.get_json(silent=True) or {}; username=valid_text(data.get("username"),40); password=str(data.get("password",""))
    with db() as con: user=con.execute("SELECT * FROM users WHERE username=?",(username or "",)).fetchone()
    if not user or not password_check(user["password_hash"],password): return jsonify(error="Неверный логин или пароль"),401
    session.clear(); session["user_id"]=user["id"]; csrf_token()
    if password_needs_upgrade(user["password_hash"]):
        with db() as con: con.execute("UPDATE users SET password_hash=? WHERE id=?",(password_hash(password),user["id"]))
    return jsonify(ok=True)

@app.post("/api/logout")
def logout(): session.clear(); return jsonify(ok=True)

@app.get("/api/me")
def me():
    u=current_user(); return jsonify(logged_in=bool(u),username=u["username"] if u else None,is_admin=is_admin(u),csrf=session.get("csrf_token"))

# ---- shifts ----
def require_user():
    u=current_user(); return u

@app.get("/api/shifts")
def shifts():
    u=require_user()
    if not u:return jsonify(error="Не авторизован"),401
    q=str(request.args.get("q",""))[:100].strip().lower(); month=str(request.args.get("month",""))[:7].strip()
    sql="SELECT * FROM shifts WHERE user_id=?"; params=[u["id"]]
    if month: sql+=" AND substr(work_date,1,7)=?"; params.append(month)
    if q:
        like=f"%{q}%"; sql+=" AND (lower(work_date) LIKE ? OR lower(role) LIKE ? OR lower(note) LIKE ? OR printf('%.2f',tips) LIKE ?)"; params += [like,like,like,like]
    sql+=" ORDER BY work_date DESC, COALESCE(end_time,start_time) DESC, id DESC"
    with db() as con: rows=con.execute(sql,params).fetchall()
    return jsonify([serialize(r) for r in rows])

@app.get("/api/active")
def active():
    u=require_user()
    if not u:return jsonify(error="Не авторизован"),401
    with db() as con:r=con.execute("SELECT * FROM shifts WHERE user_id=? AND status='active' ORDER BY id DESC LIMIT 1",(u["id"],)).fetchone()
    return jsonify(serialize(r) if r else None)

@app.post("/api/shifts/start")
def start_shift():
    u=require_user()
    if not u:return jsonify(error="Не авторизован"),401
    with db() as con:
        if con.execute("SELECT id FROM shifts WHERE user_id=? AND status='active'",(u["id"],)).fetchone(): return jsonify(error="У тебя уже открыта смена"),409
        now=datetime.now(); cur=con.execute("INSERT INTO shifts(user_id,work_date,start_time,role,status) VALUES(?,?,?,?, 'active')",(u["id"],now.strftime("%Y-%m-%d"),now.strftime("%H:%M"),"Официант")); r=con.execute("SELECT * FROM shifts WHERE id=?",(cur.lastrowid,)).fetchone()
    out=serialize(r); out["backup"]=auto_backup(u["id"]); return jsonify(out),201

@app.post("/api/shifts/<int:sid>/finish")
def finish_shift(sid):
    u=require_user()
    if not u:return jsonify(error="Не авторизован"),401
    data=request.get_json(silent=True) or {}
    try: tips=float(data.get("tips",0) or 0)
    except: return jsonify(error="Чаевые должны быть числом"),400
    if tips<0 or tips>100000000:return jsonify(error="Некорректная сумма чаевых"),400
    note=valid_text(data.get("note"),1000); role=valid_text(data.get("role","Официант"),60) or "Официант"
    if note is None:return jsonify(error="Заметка слишком длинная"),400
    end=datetime.now().strftime("%H:%M")
    with db() as con:
        r=con.execute("SELECT * FROM shifts WHERE id=? AND user_id=? AND status='active'",(sid,u["id"])).fetchone()
        if not r:return jsonify(error="Активная смена не найдена"),404
        con.execute("UPDATE shifts SET end_time=?,tips=?,note=?,role=?,status='completed' WHERE id=? AND user_id=?",(end,tips,note,role,sid,u["id"])); r=con.execute("SELECT * FROM shifts WHERE id=?",(sid,)).fetchone()
    out=serialize(r); out["backup"]=auto_backup(u["id"]); return jsonify(out)

@app.post("/api/shifts")
def create_shift():
    u=require_user()
    if not u:return jsonify(error="Не авторизован"),401
    data=request.get_json(silent=True) or {}; work_date=valid_text(data.get("work_date"),10); start=valid_text(data.get("start_time"),5); end=valid_text(data.get("end_time"),5); role=valid_text(data.get("role","Официант"),60) or "Официант"; note=valid_text(data.get("note"),1000)
    try: tips=float(data.get("tips",0) or 0)
    except: return jsonify(error="Некорректные чаевые"),400
    if note is None or tips<0 or tips>100000000:return jsonify(error="Некорректные данные"),400
    try: date.fromisoformat(work_date); datetime.strptime(start,"%H:%M"); datetime.strptime(end,"%H:%M")
    except (ValueError,TypeError): return jsonify(error="Некорректная дата или время"),400
    with db() as con:
        cur=con.execute("INSERT INTO shifts(user_id,work_date,start_time,end_time,role,tips,note,status) VALUES(?,?,?,?,?,?,?,'completed')",(u["id"],work_date,start,end,role,tips,note)); r=con.execute("SELECT * FROM shifts WHERE id=?",(cur.lastrowid,)).fetchone()
    out=serialize(r); out["backup"]=auto_backup(u["id"]); return jsonify(out),201

@app.delete("/api/shifts/<int:sid>")
def delete_shift(sid):
    u=require_user()
    if not u:return jsonify(error="Не авторизован"),401
    with db() as con: cur=con.execute("DELETE FROM shifts WHERE id=? AND user_id=?",(sid,u["id"]))
    if not cur.rowcount:return jsonify(error="Смена не найдена"),404
    return jsonify(ok=True,backup=auto_backup(u["id"]))

@app.get("/api/summary")
def summary():
    u=require_user()
    if not u:return jsonify(error="Не авторизован"),401
    month=request.args.get("month") or date.today().strftime("%Y-%m")
    with db() as con: rows=con.execute("SELECT * FROM shifts WHERE user_id=? AND substr(work_date,1,7)=? AND status='completed'",(u["id"],month)).fetchall()
    return jsonify(month=month,shifts=len(rows),hours=round(sum(hours_between(r["start_time"],r["end_time"]) for r in rows),2),tips=round(sum(float(r["tips"] or 0) for r in rows),2))

@app.get("/api/backup")
def backup():
    u=require_user()
    if not u:return jsonify(error="Не авторизован"),401
    with db() as con: rows=con.execute("SELECT id,work_date,start_time,end_time,role,tips,note,status,created_at FROM shifts WHERE user_id=? ORDER BY work_date,start_time",(u["id"],)).fetchall()
    payload={"app":"WorkLog","version":8,"user":u["username"],"exported_at":datetime.now().isoformat(timespec="seconds"),"shifts":[serialize(r) for r in rows]}
    raw=json.dumps(payload,ensure_ascii=False,indent=2).encode("utf-8")
    return send_file(io.BytesIO(raw),as_attachment=True,download_name=f"worklog-{u['username']}-{date.today()}.json",mimetype="application/json")

# ---- admin settings ----
def app_settings_row():
    with db() as con:return con.execute("SELECT * FROM app_settings WHERE id=1").fetchone()

def google_configured():
    s=app_settings_row(); return bool(s and s["service_account_enc"] and decrypt_secret(s["service_account_enc"]))

def admin_user():
    with db() as con:return con.execute("SELECT * FROM users WHERE is_admin=1 ORDER BY id LIMIT 1").fetchone()

def drive_config_row():
    with db() as con:return con.execute("SELECT * FROM drive_config WHERE id=1").fetchone()

def google_settings_public():
    s=app_settings_row(); cfg=drive_config_row(); raw=decrypt_secret(s["service_account_enc"]) if s else ""; email=""
    if raw:
        try: email=json.loads(raw).get("client_email","")
        except Exception: pass
    return {"configured":bool(raw),"service_account_email":email,"service_account_set":bool(raw),"drive_admin_email":(s["drive_admin_email"] if s and "drive_admin_email" in s.keys() else "") or "","folder_name":(cfg["folder_name"] if cfg else (s["folder_name"] if s and s["folder_name"] else "WorkLog — Смены")),"public_read":bool(cfg["public_read"]) if cfg else bool(s["public_read"]) if s else False}

@app.get("/api/admin/settings")
def admin_settings_get():
    u=current_user()
    if not is_admin(u):return jsonify(error="Доступ только для администратора"),403
    return jsonify(username=u["username"],google=google_settings_public())

@app.post("/api/admin/account")
def admin_account():
    u=current_user()
    if not is_admin(u):return jsonify(error="Доступ только для администратора"),403
    data=request.get_json(silent=True) or {}; current=str(data.get("current_password","")); new_username=valid_text(data.get("username"),40); new_password=str(data.get("new_password","")); confirm=str(data.get("confirm_password",""))
    if not password_check(u["password_hash"],current):return jsonify(error="Текущий пароль неверный"),400
    if not new_username or not re.fullmatch(r"[A-Za-zА-Яа-яЁё0-9_.-]+",new_username):return jsonify(error="Некорректный логин"),400
    if new_password and (len(new_password)<8 or new_password!=confirm):return jsonify(error="Новый пароль: минимум 8 символов, подтверждение должно совпадать"),400
    try:
        with db() as con: con.execute("UPDATE users SET username=?, password_hash=? WHERE id=?",(new_username,password_hash(new_password) if new_password else u["password_hash"],u["id"]))
        return jsonify(ok=True,username=new_username)
    except sqlite3.IntegrityError:return jsonify(error="Такой логин уже занят"),409

@app.post("/api/admin/google/service-account")
def admin_service_account():
    u=current_user()
    if not is_admin(u):return jsonify(error="Доступ только для администратора"),403
    f=request.files.get("file")
    if not f:return jsonify(error="Загрузите JSON-файл Service Account"),400
    raw=f.read(64*1024+1)
    if len(raw)>64*1024:return jsonify(error="JSON-ключ слишком большой"),400
    try:data=json.loads(raw.decode("utf-8"))
    except Exception:return jsonify(error="Файл не является корректным JSON"),400
    if data.get("type")!="service_account" or not {"project_id","private_key","client_email"}.issubset(data):return jsonify(error="Это не JSON-ключ Google Service Account"),400
    # Validate the actual Google service-account credentials and return a useful
    # diagnostic instead of the old generic message. Google JSON keys normally
    # contain type/project_id/private_key/client_email/client_id/private_key_id.
    try:
        if not isinstance(data.get("private_key"), str) or "BEGIN PRIVATE KEY" not in data["private_key"]:
            return jsonify(error="В JSON отсутствует корректный private_key Service Account"),400
        if not isinstance(data.get("client_email"), str) or "@" not in data["client_email"]:
            return jsonify(error="В JSON отсутствует корректный client_email Service Account"),400
        serialization.load_pem_private_key(data["private_key"].encode(),password=None)
    except ValueError as exc:
        return jsonify(error="Приватный ключ Service Account повреждён или имеет неверный формат: "+str(exc)[:180]),400
    except Exception as exc:
        return jsonify(error="Не удалось прочитать ключ Service Account: "+str(exc)[:220]),400
    folder_name=valid_text(request.form.get("folder_name"),100) or "WorkLog — Смены"; admin_email=valid_text(request.form.get("admin_email"),254) or ""; public_read=request.form.get("public_read") in {"1","true","on","yes"}
    enc=encrypt_secret(json.dumps(data,ensure_ascii=False))
    with db() as con:
        con.execute("INSERT INTO app_settings(id,service_account_enc,folder_name,public_read,drive_admin_email,updated_at) VALUES(1,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET service_account_enc=excluded.service_account_enc,folder_name=excluded.folder_name,public_read=excluded.public_read,drive_admin_email=excluded.drive_admin_email,updated_at=CURRENT_TIMESTAMP",(enc,folder_name,1 if public_read else 0,admin_email))
    return jsonify(ok=True,google=google_settings_public())

@app.post("/api/admin/google/settings")
def admin_google_settings():
    u=current_user()
    if not is_admin(u):return jsonify(error="Доступ только для администратора"),403
    data=request.get_json(silent=True) or {}; folder_name=valid_text(data.get("folder_name"),100) or "WorkLog — Смены"; admin_email=valid_text(data.get("admin_email"),254) or ""; public_read=bool(data.get("public_read",False))
    with db() as con:
        old=con.execute("SELECT service_account_enc FROM app_settings WHERE id=1").fetchone()
        if not old or not old["service_account_enc"]:return jsonify(error="Сначала загрузите JSON Service Account"),400
        con.execute("UPDATE app_settings SET folder_name=?,public_read=?,drive_admin_email=?,updated_at=CURRENT_TIMESTAMP WHERE id=1",(folder_name,1 if public_read else 0,admin_email))
    return jsonify(ok=True,google=google_settings_public())

@app.post("/api/admin/google/disconnect")
def admin_google_disconnect():
    u=current_user()
    if not is_admin(u):return jsonify(error="Доступ только для администратора"),403
    with db() as con:
        con.execute("DELETE FROM google_tokens"); con.execute("DELETE FROM drive_config"); con.execute("DELETE FROM drive_backups"); con.execute("UPDATE app_settings SET service_account_enc=NULL,drive_admin_email=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=1")
    return jsonify(ok=True)

# ---- Google Drive via Service Account ----
GOOGLE_TOKEN_URL="https://oauth2.googleapis.com/token"
DRIVE_API="https://www.googleapis.com/drive/v3"

class DriveClient:
    def __init__(self, data):
        self.data=data
        self._token=None
        self._expires=0
    def _b64(self,b):
        return base64.urlsafe_b64encode(b).rstrip(b"=").decode()
    def token(self):
        now=int(time.time())
        if self._token and now < self._expires-60:return self._token
        header={"alg":"RS256","typ":"JWT"}
        payload={"iss":self.data["client_email"],"scope":"https://www.googleapis.com/auth/drive","aud":GOOGLE_TOKEN_URL,"iat":now,"exp":now+3600}
        unsigned=self._b64(json.dumps(header,separators=(",",":"),sort_keys=True).encode())+"."+self._b64(json.dumps(payload,separators=(",",":"),sort_keys=True).encode())
        key=serialization.load_pem_private_key(self.data["private_key"].encode(),password=None)
        sig=key.sign(unsigned.encode(),padding.PKCS1v15(),hashes.SHA256())
        assertion=unsigned+"."+self._b64(sig)
        r=requests.post(GOOGLE_TOKEN_URL,data={"grant_type":"urn:ietf:params:oauth:grant-type:jwt-bearer","assertion":assertion},timeout=20)
        if r.status_code!=200: raise RuntimeError(f"Google token error {r.status_code}: {r.text[:400]}")
        d=r.json(); self._token=d["access_token"]; self._expires=now+int(d.get("expires_in",3600)); return self._token
    def req(self,method,path,params=None,json_body=None,data=None,files=None):
        headers={"Authorization":"Bearer "+self.token()}
        if json_body is not None:headers["Content-Type"]="application/json"
        r=requests.request(method,DRIVE_API+path,params=params,json=json_body,data=data,files=files,headers=headers,timeout=30)
        if r.status_code>=400: raise RuntimeError(f"Google Drive HTTP {r.status_code}: {r.text[:600]}")
        return r.json() if r.content else {}
    def about(self):return self.req("GET","/about",params={"fields":"user(emailAddress,displayName),storageQuota(limit,usage)"})
    def permissions_list(self,file_id):return self.req("GET",f"/files/{file_id}/permissions",params={"fields":"permissions(id,type,emailAddress,role)"})
    def permissions_create(self,file_id,body):return self.req("POST",f"/files/{file_id}/permissions",params={"sendNotificationEmail":"false","fields":"id"},json_body=body)
    def permissions_delete(self,file_id,pid):return self.req("DELETE",f"/files/{file_id}/permissions/{pid}")
    def file_get(self,file_id):return self.req("GET",f"/files/{file_id}",params={"fields":"id,name,webViewLink"})
    def file_list(self,q):return self.req("GET","/files",params={"q":q,"spaces":"drive","fields":"files(id,name,webViewLink)","pageSize":"10"})
    def file_create(self,body,content):
        boundary="worklog-boundary-"+secrets.token_hex(8)
        meta=json.dumps(body,ensure_ascii=False).encode(); b=boundary.encode()
        multipart=(b"--"+b+b"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+meta+b"\r\n--"+b+b"\r\nContent-Type: application/json\r\n\r\n"+content+b"\r\n--"+b+b"--\r\n")
        r=requests.post("https://www.googleapis.com/upload/drive/v3/files",params={"uploadType":"multipart","fields":"id,name,webViewLink"},headers={"Authorization":"Bearer "+self.token(),"Content-Type":"multipart/related; boundary="+boundary},data=multipart,timeout=30)
        if r.status_code>=400:raise RuntimeError(f"Google Drive HTTP {r.status_code}: {r.text[:600]}")
        return r.json()
    def file_update(self,file_id,content):
        r=requests.patch("https://www.googleapis.com/upload/drive/v3/files/"+file_id,params={"uploadType":"media","fields":"id,name,webViewLink"},headers={"Authorization":"Bearer "+self.token(),"Content-Type":"application/json"},data=content,timeout=30)
        if r.status_code>=400:raise RuntimeError(f"Google Drive HTTP {r.status_code}: {r.text[:600]}")
        return r.json()

def _load_sa_data():
    s=app_settings_row(); raw=decrypt_secret(s["service_account_enc"]) if s and s["service_account_enc"] else ""
    if not raw:return None,"Service Account не настроен"
    try:
        d=json.loads(raw)
        if d.get("type")!="service_account":return None,"JSON не является Service Account (type должен быть service_account)"
        for k in ("project_id","private_key","client_email","token_uri"):
            if not d.get(k):return None,f"В JSON отсутствует поле {k}"
        serialization.load_pem_private_key(d["private_key"].encode(),password=None)
        return d,None
    except Exception as exc:return None,"Не удалось прочитать Service Account: "+str(exc)[:300]

def _drive_service():
    d,err=_load_sa_data()
    if err:return None,err
    try:return DriveClient(d),None
    except Exception as exc:return None,"Не удалось создать клиент Google Drive: "+str(exc)[:300]

def _set_folder_public(service,folder_id,public_read):
    try:
        perms=service.permissions_list(folder_id).get("permissions",[]); anyone=[p for p in perms if p.get("type")=="anyone"]
        if public_read and not anyone:service.permissions_create(folder_id,{"type":"anyone","role":"reader"})
        if not public_read:
            for p in anyone:
                try:service.permissions_delete(folder_id,p["id"])
                except Exception:pass
    except Exception:pass

def _share_folder_with_admin(service,folder_id):
    s=app_settings_row(); email=(s["drive_admin_email"] if s and "drive_admin_email" in s.keys() else "") or ""
    if not email:return
    try:
        perms=service.permissions_list(folder_id).get("permissions",[])
        if not any(p.get("type")=="user" and p.get("emailAddress","").lower()==email.lower() for p in perms):service.permissions_create(folder_id,{"type":"user","role":"writer","emailAddress":email})
    except Exception:pass

def _ensure_public_folder(service):
    cfg=drive_config_row(); settings=app_settings_row(); desired=cfg["folder_name"] if cfg else (settings["folder_name"] if settings and settings["folder_name"] else "WorkLog — Смены"); public=bool(cfg["public_read"]) if cfg else bool(settings["public_read"]) if settings else False
    if cfg:
        try:service.file_get(cfg["folder_id"]); _share_folder_with_admin(service,cfg["folder_id"]); _set_folder_public(service,cfg["folder_id"],public); return cfg["folder_id"],cfg["folder_url"]
        except Exception:pass
    folder=service.req("POST","/files",json_body={"name":desired,"mimeType":"application/vnd.google-apps.folder"}); folder_id=folder["id"]; _share_folder_with_admin(service,folder_id); _set_folder_public(service,folder_id,public); folder_url=folder.get("webViewLink") or f"https://drive.google.com/drive/folders/{folder_id}"; admin=admin_user()
    with db() as con:con.execute("INSERT OR REPLACE INTO drive_config(id,admin_user_id,folder_id,folder_url,folder_name,public_read,updated_at) VALUES(1,?,?,?,?,?,CURRENT_TIMESTAMP)",(admin["id"],folder_id,folder_url,desired,1 if public else 0))
    return folder_id,folder_url

def sync_user_to_drive(user_id):
    if not google_configured():return False,"Google Drive не настроен",None
    service,err=_drive_service()
    if err:return False,err,None
    try:
        folder_id,folder_url=_ensure_public_folder(service); payload=_user_payload(user_id); data=json.dumps(payload,ensure_ascii=False,indent=2).encode("utf-8")
        with db() as con:user=con.execute("SELECT username FROM users WHERE id=?",(user_id,)).fetchone(); old=con.execute("SELECT file_id FROM drive_backups WHERE user_id=?",(user_id,)).fetchone()
        safe_name="".join(c if c.isalnum() or c in " ._-" else "_" for c in user["username"]).strip() or f"user-{user_id}"; name=f"{safe_name}.json"; f=None
        if old:
            try:f=service.file_update(old["file_id"],data)
            except Exception:pass
        if not f:
            safe_q=name.replace("'","\\'"); q=f"'{folder_id}' in parents and name = '{safe_q}' and trashed = false"; found=service.file_list(q).get("files",[])
            if found:f=service.file_update(found[0]["id"],data)
            else:f=service.file_create({"name":name,"parents":[folder_id],"mimeType":"application/json","description":"WorkLog automatic backup"},data)
        cfg=drive_config_row(); _set_folder_public(service,folder_id,bool(cfg["public_read"]) if cfg else False)
        with db() as con:con.execute("INSERT OR REPLACE INTO drive_backups(user_id,file_id,updated_at) VALUES(?,?,CURRENT_TIMESTAMP)",(user_id,f["id"]))
        return True,"Синхронизировано",f.get("webViewLink") or folder_url
    except Exception as exc:return False,"Ошибка Drive: "+str(exc)[:300],None

def sync_all_users_to_drive():
    with db() as con:ids=[r["id"] for r in con.execute("SELECT id FROM users ORDER BY id").fetchall()]
    return [(uid,)+sync_user_to_drive(uid) for uid in ids]

def auto_backup(uid):
    try:return sync_user_to_drive(uid)[0]
    except Exception:return False

@app.get("/api/health")
def health():
    return jsonify(ok=True, service_account_configured=google_configured(), secure=request.is_secure)

@app.get("/api/google/status")
def google_status():
    u=current_user()
    if not u:return jsonify(error="Не авторизован"),401
    cfg=drive_config_row(); return jsonify(configured=google_configured(),is_admin=is_admin(u),connected=bool(cfg),folder_url=cfg["folder_url"] if cfg else None,public_read=bool(cfg["public_read"]) if cfg else None)

@app.get("/api/google/diagnostics")
def google_diagnostics():
    u=current_user()
    if not is_admin(u): return jsonify(error="Доступ только для администратора"),403
    result={"configured":google_configured(),"credentials":"not_checked","drive":"not_checked","folder":"not_checked"}
    service,err=_drive_service()
    if err:
        result["credentials_error"]=err
        return jsonify(ok=False,**result),400
    result["credentials"]="ok"
    try:
        about=service.about().get(fields="user(emailAddress),storageQuota(limit,usage)").execute()
        result["service_account_email"]=about.get("user",{}).get("emailAddress","")
        result["drive"]="ok"
        folder_id,folder_url=_ensure_public_folder(service)
        result["folder"]="ok"; result["folder_id"]=folder_id; result["folder_url"]=folder_url
        return jsonify(ok=True,**result)
    except Exception as exc:
        result["drive_error"]=str(exc)[:500]
        return jsonify(ok=False,**result),400

@app.post("/api/google/test")
def google_test():
    u=current_user()
    if not is_admin(u):return jsonify(error="Доступ только для администратора"),403
    service,err=_drive_service()
    if err:return jsonify(error=err),400
    try:
        about=service.about().get(fields="user(emailAddress,displayName)").execute(); folder_id,folder_url=_ensure_public_folder(service)
        return jsonify(ok=True,service_account=about.get("user",{}).get("emailAddress",""),folder_url=folder_url,folder_id=folder_id)
    except Exception as exc:return jsonify(error="Google Drive недоступен: "+str(exc)[:220]),400

@app.post("/api/google/backup")
def google_backup():
    u=current_user()
    if not is_admin(u):return jsonify(error="Доступ только для администратора"),403
    results=sync_all_users_to_drive(); bad=[x for x in results if not x[1]]
    return jsonify(ok=not bad,failed=len(bad),total=len(results))

init_db()

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","5000")),debug=False)
